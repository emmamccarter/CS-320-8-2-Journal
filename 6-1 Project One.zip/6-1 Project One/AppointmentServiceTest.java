package AppointmentServiceTest;

public class Appointment {
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class AppointmentServiceTest {
        
    AppointmentService AppointmentService = new AppointmentService();
                                                
    Appointment 4 = new Appointment("4", "2022-03-05", "Raleigh 786598546 Pink Blossom");
    Appointment 5 = new Appointment("5", "2022-04-02", "Beach 836792565 Redondo Beach");
                                
    if(AppointmentService.addAppointment(4)) {
                                                        
           System.out.println("\nadded");
                                                        
     }else {
                                                        
           System.out.println("\nfailure to add appointment");
      }
                                                
     if(AppointmentService.addAppointment(5)) {
                                                        
     System.out.println("\nadded");
                                                        
      }
     else {
                                                        
     System.out.println("\nfailure to add appointment");
      }
                                                
     if(AppointmentService.addAppointment(4)) {
                                                                        
      System.out.println("\nadded");
          
      }
    else {
                                                                        
    System.out.println("\nfailure to add appointment");
                                }
                                                
                                                
    AppointmentService.displayAll();
                                                
    AppointmentService.deleteAppointment("4");
                                
    if(AppointmentService.deleteAppointment("4")) {
                                                        
    System.out.println("\ndeleted");
                                                        
      
      }
      else {
                                                        
      System.out.println("\nalready deleted");
                                                        
       }

                                
      AppointmentService.displayAll();
                

        }
}
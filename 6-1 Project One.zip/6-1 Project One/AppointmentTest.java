package AppointmentTest;

import java.util.Calendar;
import java.util.Date;

class AppointmentTest {

  private String id, description;
  private String tooLongId, tooLongDescription;
  private Date date, pastDate;
    
                }

}
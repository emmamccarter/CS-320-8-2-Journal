package contact;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ContactServiceTest {

  
@Test
public void testAdd()
{
ContactService cs = new ContactService();
Contact test1 = new Contact("4828594", "Mae", "McCarter", "2522582168", "6348 Marvin Taylor Road");
assertEquals(true, cs.addContact(test1));
}

@Test
public void testDelete()
{
   ContactService cs = new ContactService();
     
Contact test1 = new Contact("1953477", "Gigi", "Carmona", "3105946215", "4567 W 163rd St.");
Contact test2 = new Contact("5621897", "Lala", "Mason", "3106948223", "Simi Valley");
Contact test3 = new Contact("6277798", "Richard", "Fiore", "8186249875", "San Jacinto");

cs.addContact(test1);
cs.addContact(test2);
cs.addContact(test3);

assertEquals(true, cs.deleteContact("5621897"));
assertEquals(false, cs.deleteContact("5621898"));
assertEquals(false, cs.deleteContact("5621897"));
}

@Test
public void testUpdate()
{
ContactService cs = new ContactService();
     
Contact test1 = new Contact("1953477", "Gigi", "Carmona", "3105946215", "4567 W 163rd St.");
Contact test2 = new Contact("5621897", "Lala", "Mason", "3106948223", "Simi Valley");
Contact test3 = new Contact("6277798", "Richard", "Fiore", "8186249875", "San Jacinto");

cs.addContact(test1);
cs.addContact(test2);
cs.addContact(test3);

assertEquals(true, cs.updateContact("1953477", "GigiFirst", "CarmonaLast", "3105946215", "4567 W 163rd St."));
assertEquals(false, cs.updateContact("1953588", "GigiFirst", "CarmonaLast", "3105946215", "4567 W 163rd St."));
}

}
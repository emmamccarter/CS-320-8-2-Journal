package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import static org.junit.Assert.*;

import contact.Contact;
import contact.ContactService;

class ContactServiceTest {

  
   @Test
   public void testAdd()
   {
       ContactService cs = new ContactService();
       Contact test1 = new Contact("5294638", "Emma", "McCarter", "2522582168", "4116 Kittrell Farms Drive");
       assertEquals(true, cs.addContact(test1));
   }
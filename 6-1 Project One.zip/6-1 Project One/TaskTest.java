import org.junit.Assert;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class TaskTest {

  @Test public void createValidTaskData() {
      Task task = new Task("10", "Exercise", "Walk a mile");
      System.out.println(task);
   }
   
}